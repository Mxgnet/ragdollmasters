/*
 * Decompiled with CFR 0.152.
 */
package ragdollmultimasters;

import ragdollmultimasters.MainForm;

public class RagdollMultiMasters {
    public static boolean HOST = false;

    public static void main(String[] args) {
        MainForm form = new MainForm();
        form.setVisible(true);
    }
}

