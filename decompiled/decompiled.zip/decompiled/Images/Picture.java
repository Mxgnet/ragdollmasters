/*
 * Decompiled with CFR 0.152.
 */
package Images;

import java.awt.Image;

public abstract class Picture {
    public abstract Image getImage();
}

